import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Contact } from '../Model/Contact';
import { CustomerService } from '../services/customer.service';
import { FaqsComponent } from '../faqs/faqs.component';
import { FAQ } from '../Model/FAQs';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent {
contact = new Contact();
constructor(private customerService: CustomerService){}
onSubmit(contact: Contact) {
  this.customerService.contactAdmin(contact);
}
faqs: FAQ[] = [
  { question: 'What is a loan?', answer: 'A loan is...' },
  { question: 'How can I apply for a loan?', answer: 'You can apply...' },
  // Add more FAQs as needed
];

}
