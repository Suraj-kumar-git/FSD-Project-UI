import { Component } from '@angular/core';

@Component({
  selector: 'app-notifications-admin',
  templateUrl: './notifications-admin.component.html',
  styleUrls: ['./notifications-admin.component.css']
})
export class NotificationsAdminComponent {

}
