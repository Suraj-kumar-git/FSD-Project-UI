import { Component } from '@angular/core';
import { LoanApplications } from '../Model/LoanApplications';
import { CustomerService } from '../services/customer.service';
import { UserAuthService } from '../services/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-loans',
  templateUrl: './customer-loans.component.html',
  styleUrls: ['./customer-loans.component.css']
})
export class CustomerLoansComponent {
cancelLoan(arg0: number) {
throw new Error('Method not implemented.');
}
  loanApplication :LoanApplications[] = [];

  constructor(private customerService:CustomerService, private userAuthservice:UserAuthService,private router:Router){}

  ngOnInit(){
    this.getAllAppliedLoan();
  }
customerId = this.userAuthservice.getCustomer().customerId;
getAllAppliedLoan(){
  this.customerService.getAppliedLoans(this.customerId).subscribe(
    response => {
      this.loanApplication = response.map(loan => {
        return {
          ...loan,
          loanTypeName: loan.loanType.loanTypeName,
          tenure:loan.tenureInMonths
        };
      });
      console.log(this.loanApplication);
    }
  );
}
updateLoan(loanId:number){
  console.log(loanId);
  this.router.navigate(['customer/update-applied-loan',loanId])
}

  
}
