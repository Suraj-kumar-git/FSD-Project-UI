import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { Customer } from '../Model/Customer';

@Component({
  selector: 'app-customer-register',
  templateUrl: './customer-register.component.html',
  styleUrls: ['./customer-register.component.css']
})
export class CustomerRegisterComponent {
  registrationForm!: FormGroup;

  customer:Customer = new Customer();
  file!:File;

  indianStates: string[] = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat',
    'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra',
    'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
    'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Andaman and Nicobar Islands',
    'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Lakshadweep', 'Puducherry'
  ];
  constructor(private fb: FormBuilder,private userService:UserService,private router:Router) { }

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      address: ['', Validators.required],
      state: ['', Validators.required],
      creditScore: ['', Validators.required],
      panCardNumber: ['', Validators.required],
      idProof: [null, Validators.required]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password');
    const confirmPassword = form.get('confirmPassword');
    return password && confirmPassword && password.value === confirmPassword.value ? null : { passwordMismatch: true };
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      // this.customer=this.registrationForm.value;
      // console.log(this.customer);
      this.customer.customerFirstName=this.registrationForm.value.FirstName;
      this.customer.customerLastName=this.registrationForm.value.LastName;
      this.customer.phoneNumber=this.registrationForm.value.phoneNumber;
      this.customer.email=this.registrationForm.value.email;
      this.customer.password=this.registrationForm.value.password;
      this.customer.dateOfBirth=this.registrationForm.value.dateOfBirth;
      this.customer.gender=this.registrationForm.value.gender;
      this.customer.fullAddress=this.registrationForm.value.address;
      this.customer.state=this.registrationForm.value.state;
      this.customer.creditScore=this.registrationForm.value.creditScore;
      this.customer.panCardNumber=this.registrationForm.value.panCardNumber;
      console.log(this.customer);
      this.userService.register(this.customer, this.file).subscribe(response => {
        if(response==true) {
          this.router.navigate(['/login']);
          alert('You registeration is successfull,Please login with the credentials to continue.');
        }else{
          alert('Registration Failed:');
        }
      });
    } else {
      this.registrationForm.markAllAsTouched();
      console.log(this.registrationForm.value);
      alert("Not filled correctly...")
    }
  }
  onFileUpload(event: any){
    this.file=event.target.files[0];
    console.log(this.file.name);
  }
}
