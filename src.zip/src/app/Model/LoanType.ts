export class LoanType{
  loanTypeId!:number;
	loanTypeName!:string;
	loanInterestBaseRate!:number;
	loanManagementFees!:number;
	isEditing!: boolean;
	
}