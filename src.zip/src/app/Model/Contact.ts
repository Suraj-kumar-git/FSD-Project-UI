export class Contact {
  firstName!: string;
  lastName!: string;
  customerId!:number;
  email!: string;
  subject!: string;
  description!: string;
}