export class Admin{
  adminId!:number;
  adminFirstName!: string;
  adminLastName!: string;
  email!: string;
  password!: string;
}