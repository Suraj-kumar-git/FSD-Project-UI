export class Login{
  username:string='';
  password:string='';
  role:string='';
}